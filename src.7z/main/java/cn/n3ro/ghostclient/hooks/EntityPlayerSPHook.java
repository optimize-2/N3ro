package cn.n3ro.ghostclient.hooks;

import cn.n3ro.ghostclient.Client;
import cn.n3ro.ghostclient.events.EventMotion;
import cn.n3ro.ghostclient.events.EventUpdate;
import cn.n3ro.ghostclient.utils.ASMUtil;
import cn.n3ro.ghostclient.utils.LoggerUtils;
import com.darkmagician6.eventapi.EventManager;
import com.darkmagician6.eventapi.types.EventType;
import net.minecraft.client.Minecraft;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.*;

/**
 *
 * addChatMessage func_145747_a
 *
 *
 */
public class EntityPlayerSPHook implements Opcodes{

    public static void transformEntityPlayerSP(ClassNode classNode, MethodNode method) {
        if (method.name.equalsIgnoreCase("func_70071_h_") | method.name.equalsIgnoreCase("onUpdate")){
            method.instructions.insert(new MethodInsnNode(Opcodes.INVOKESTATIC, Type.getInternalName(EntityPlayerSPHook.class),"hookOnUpdate","()V",false));
        }
        if (method.name.equalsIgnoreCase("func_175161_p") | method.name.equalsIgnoreCase("onUpdateWalkingPlayer")){
            InsnList preInsn = new InsnList();
            preInsn.add(new FieldInsnNode(GETSTATIC, "com/darkmagician6/eventapi/types/EventType", "PRE", "Lcom/darkmagician6/eventapi/types/EventType;"));
            preInsn.add(new MethodInsnNode(INVOKESTATIC, Type.getInternalName(EntityPlayerSPHook.class), "hookMotionUpdate","(Lcom/darkmagician6/eventapi/types/EventType;)V", false));
            method.instructions.insert(preInsn);

            InsnList postInsn = new InsnList();
            postInsn.add(new FieldInsnNode(GETSTATIC, "com/darkmagician6/eventapi/types/EventType", "POST", "Lcom/darkmagician6/eventapi/types/EventType;"));
            postInsn.add(new MethodInsnNode(INVOKESTATIC, Type.getInternalName(EntityPlayerSPHook.class), "hookMotionUpdate","(Lcom/darkmagician6/eventapi/types/EventType;)V", false));
            method.instructions.insertBefore(ASMUtil.bottom(method), postInsn);


            // replace field
            for (AbstractInsnNode abstractInsnNode : method.instructions.toArray()){
                if (abstractInsnNode.getOpcode() == ALOAD &
                        abstractInsnNode.getNext() instanceof FieldInsnNode
                ){
                    if ( ((FieldInsnNode) abstractInsnNode.getNext()).name.equalsIgnoreCase(Client.runtimeobfuscationEnabled ? "field_70163_u" : "posY")
                    ){
                        method.instructions.set(abstractInsnNode.getNext(),
                                new FieldInsnNode(GETSTATIC, Type.getInternalName(EventMotion.class),
                                        "y","D"));
                        method.instructions.remove(abstractInsnNode);
                    }else if ( ((FieldInsnNode) abstractInsnNode.getNext()).name.equalsIgnoreCase(Client.runtimeobfuscationEnabled ? "field_70177_z" : "rotationYaw")
                    ){
                        method.instructions.set(abstractInsnNode.getNext(),
                                new FieldInsnNode(GETSTATIC,Type.getInternalName(EventMotion.class),
                                        "yaw","F"));
                        method.instructions.remove(abstractInsnNode);
                    }else if ( ((FieldInsnNode) abstractInsnNode.getNext()).name.equalsIgnoreCase(Client.runtimeobfuscationEnabled ? "field_70125_A" : "rotationPitch")
                    ){
                        method.instructions.set(abstractInsnNode.getNext(),
                                new FieldInsnNode(GETSTATIC,Type.getInternalName(EventMotion.class),
                                        "pitch","F"));
                        method.instructions.remove(abstractInsnNode);
                    } else if ( ((FieldInsnNode) abstractInsnNode.getNext()).name.equalsIgnoreCase(Client.runtimeobfuscationEnabled ? "field_70122_E" : "onGround")
					){
						method.instructions.set(abstractInsnNode.getNext(),
								new FieldInsnNode(GETSTATIC,Type.getInternalName(EventMotion.class),
										"onGround","Z"));
						method.instructions.remove(abstractInsnNode);
					}
                }
            }
        }
    }
    public static void hookMotionUpdate(EventType stage) {
        if (stage == EventType.PRE){
            EventMotion em = new EventMotion(Minecraft.getMinecraft().thePlayer.posY, Minecraft.getMinecraft().thePlayer.rotationYaw,Minecraft.getMinecraft().thePlayer.rotationPitch,Minecraft.getMinecraft().thePlayer.onGround);
            EventManager.call(em);
        }else if (stage == EventType.POST){
            EventMotion ep = new EventMotion(stage);
            EventManager.call(ep);
        }

    }

    public static void hookOnUpdate(){
        EventManager.call(new EventUpdate());
    }

}
