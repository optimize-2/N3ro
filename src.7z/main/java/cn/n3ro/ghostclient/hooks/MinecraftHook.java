package cn.n3ro.ghostclient.hooks;

import cn.n3ro.ghostclient.Client;
import cn.n3ro.ghostclient.events.EventRender2D;
import cn.n3ro.ghostclient.events.EventRender3D;
import cn.n3ro.ghostclient.events.EventTick;
import cn.n3ro.ghostclient.management.ModuleManager;
import cn.n3ro.ghostclient.module.Module;
import cn.n3ro.ghostclient.utils.GLUProjection;
import com.darkmagician6.eventapi.EventManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GLAllocation;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.Iterator;

public class MinecraftHook {

    public static void transformMinecraft(ClassNode clazz, MethodNode method) {
        Iterator<AbstractInsnNode> iter = method.instructions.iterator();
        while (iter.hasNext()) {
            AbstractInsnNode insn = iter.next();
            if (insn.getOpcode() == Opcodes.INVOKEVIRTUAL) {
                MethodInsnNode methodInsn = (MethodInsnNode) insn;
                if (methodInsn.name.equals("func_71407_l") || methodInsn.name.equals("runTick")) {
                    method.instructions.insert(insn, new MethodInsnNode(Opcodes.INVOKESTATIC,//opcodes invoke static method
                            Type.getInternalName(MinecraftHook.class), //method ownner
                            "hookRunTick", //method name
                            "()V", //method desc
                            false));
                }
                if (methodInsn.name.equals("dispatchKeypresses") | method.name.equalsIgnoreCase("func_152348_aa")) {
                    method.instructions.insert(insn, new MethodInsnNode(Opcodes.INVOKESTATIC, Type.getInternalName(MinecraftHook.class), "hookKeyHandler", "()V", false));
                }
            }
        }
    }


    /**
     * ghost client start method
     */
    public static void hookRunTick() {
        if (!Client.initiated) {
            new Client();
        }
        EventManager.call(new EventTick());
    }

    /**
     * KeyHandler method
     */
    public static void hookKeyHandler() {
        if (Keyboard.getEventKeyState()) {
            for (Module mod : Client.instance.moduleManager.getModList()) {
                if (Minecraft.getMinecraft().currentScreen == null) {
                    if (mod.getKey() != (Keyboard.getEventKey() == 0 ? Keyboard.getEventCharacter() + 256 : Keyboard.getEventKey()))
                        continue;
                    mod.set(!mod.isEnable());
                }
                break;
            }
        }
    }

}
