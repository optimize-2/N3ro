package cn.n3ro.ghostclient.management;

import cn.n3ro.ghostclient.module.Module;
import cn.n3ro.ghostclient.module.modules.MISC.Packet;
import cn.n3ro.ghostclient.module.modules.MOVEMENT.Bhop;
import cn.n3ro.ghostclient.module.modules.MOVEMENT.Eagle;
import cn.n3ro.ghostclient.module.modules.MOVEMENT.InvMove;
import cn.n3ro.ghostclient.module.modules.MOVEMENT.Sprint;
import cn.n3ro.ghostclient.module.modules.RENDER.Arraylist;
import cn.n3ro.ghostclient.utils.LoggerUtils;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public static ArrayList<Module> modList = new ArrayList<>();

    public ModuleManager() {
        addModule(new Sprint());
        addModule(new Bhop());
        addModule(new InvMove());
        addModule(new Eagle());
        addModule(new Packet());
        addModule(new Arraylist());
    }

    public void addModule(Module module) {
        modList.add(module);
    }

    public static List<Module> getModList() {
        return modList;
    }
}
