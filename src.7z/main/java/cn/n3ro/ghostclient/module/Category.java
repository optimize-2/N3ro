package cn.n3ro.ghostclient.module;

public enum Category {
    COMBAT,MOVEMENT,PLAYER,RENDER,WORLD;
}
