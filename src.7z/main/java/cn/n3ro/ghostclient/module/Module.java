package cn.n3ro.ghostclient.module;

import cn.n3ro.ghostclient.utils.PlayerUtil;
import com.darkmagician6.eventapi.EventManager;
import net.minecraft.client.Minecraft;

import java.awt.*;

public class Module {
    public int key;
    public String name;
    public Category category;
    public boolean enable;
    public static Minecraft mc = Minecraft.getMinecraft();
    public String displayname;
    private CheckboxMenuItem checkboxMenuItem;


    public Module(String name,Category category){
        this.name = name;
        this.category = category;
        this.key = -1;
    }

    public void setDisplayname(String displayname) {
        this.displayname = displayname;
    }

    public String getDisplayname() {
        return displayname;
    }

    public void setKey(int key) {
        this.key = key;
    }

    public boolean isEnable() {
        return enable;
    }

    public void onToggle(){
        
    }

    public Category getCategory() {
        return category;
    }

    public String getName() {
        return name;
    }

    public int getKey() {
        return key;
    }

    public void set(boolean stage){
        this.enable = stage;
        this.onToggle();
        if (stage){
            if (mc.theWorld != null){
                this.onEnable();
            }
            EventManager.register(this);
        }else{
            if (mc.theWorld != null){
                this.onDisable();
            }
            EventManager.unregister(this);
        }
    }

    public void toggleModule() {
        if (this.checkboxMenuItem != null) {
            this.checkboxMenuItem.setState(!this.checkboxMenuItem.getState());
        }
        this.set(!this.isEnable());
    }
    public void setCheckboxMenuItem(CheckboxMenuItem checkboxMenuItem) {
        this.checkboxMenuItem = checkboxMenuItem;
    }

    public void onDisable(){
        
    }
    
    public void onEnable(){
        
    }
    
}
