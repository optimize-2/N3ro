package cn.n3ro.ghostclient.module.modules.MISC;

public class Patcher {
}
